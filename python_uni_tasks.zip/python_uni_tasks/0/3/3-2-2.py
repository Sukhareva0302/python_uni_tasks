from function import f
import numpy as np
an=np.random.randn(20,19)
f(an)
