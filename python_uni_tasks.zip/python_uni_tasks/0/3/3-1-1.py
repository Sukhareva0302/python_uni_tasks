import numpy as np
import pandas as pd

a=np.random.rand(20, 19)

an=np.random.randn(20,19)
print('uniform distribution:',a)
print('normal distribution:',an)
