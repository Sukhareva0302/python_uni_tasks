import numpy as np
import pandas as pd
import sklearn as sk
import tensorflow as tf
import keras

print ("numpy version =", np.__version__)
print ("pandas version =", pd.__version__)
print ("sklearn version =", sk.__version__)
print ("tensorflow version =", tf.__version__)
print ("keras version =", keras.__version__)
